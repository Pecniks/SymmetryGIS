#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <iostream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->SymDisplayWidget->setSeparateColors(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionLoad_triggered()
{
    QString fileName=QFileDialog::getOpenFileName((QWidget*)this,"Open point cloud file",".","Point cloud files (*.pc *.xyz)");
    if(fileName != "") {
        pointCloud.loadPointCloud(fileName);

        ui->PCDisplayWidget->prepareObject(&pointCloud);

        ui->PCDisplayWidget->setPointSize(3);

        ui->PCDisplayWidget->update();
    }
}

void MainWindow::on_actionDetermine_symmetry_triggered()
{
    SymetryPlaneData plane=symCalculator.determineSymetryPlane(pointCloud.getPoints());
    std::cout << "S: " << plane.symetry << std::endl;
    std::cout << "X: " << plane.normal.x << " Y: " << plane.normal.y << " Z: " << plane.normal.z << std::endl;

    ui->SymDisplayWidget->prepareObjectLR(&pointCloud, plane.normal);

    ui->SymDisplayWidget->setPointSize(3);

    ui->SymDisplayWidget->update();
}

