#ifndef POINTCLOUD_H
#define POINTCLOUD_H

#include <vector>
#include <QString>
#include "struct_const.h"

class PointCloud
{
public:
    PointCloud();

    std::vector<Point3D> getPoints();

    void loadPointCloud(QString fileName);

    std::vector<float> getVertices();

protected:
    void setToCOG();

    std::vector<Point3D> points;
};

#endif // POINTCLOUD_H
