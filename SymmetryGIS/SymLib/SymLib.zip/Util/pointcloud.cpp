#include "pointcloud.h"
#include <QFile>
#include <QTextStream>

PointCloud::PointCloud()
{

}

std::vector<Point3D> PointCloud::getPoints()
{
    return points;
}

void PointCloud::loadPointCloud(QString fileName) {
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream in(&file);
    QString line=in.readLine();
    QStringList lst;

    points.clear();

    while (!in.atEnd()) {
        line = in.readLine();
        lst=line.split(" ");
        Point3D v(lst[0].toDouble(),lst[1].toDouble(),lst[2].toDouble());
        points.push_back(v);
    }

    setToCOG();
}

void PointCloud::setToCOG() {
    int i;
    Point3D cog(0,0,0);

    double N=points.size();

    for(i=0;i<points.size();i++) {
        cog.x += points[i].x;
        cog.y += points[i].y;
        cog.z += points[i].z;
    }

    cog.x /= N;
    cog.y /= N;
    cog.z /= N;

    for(i=0;i<points.size();i++) {
        points[i].x -= cog.x;
        points[i].y -= cog.y;
        points[i].z -= cog.z;
    }
}

std::vector<float> PointCloud::getVertices() {
    std::vector<float> v;
    v.clear();

    int i;
    for(i=0;i<points.size();i++) {
        v.push_back(points[i].x);
        v.push_back(points[i].y);
        v.push_back(points[i].z);
    }

    return v;
}
