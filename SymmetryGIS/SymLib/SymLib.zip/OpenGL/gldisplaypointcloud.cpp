#include "gldisplaypointcloud.h"

GLDisplayPointCloud::GLDisplayPointCloud(QWidget *parent) :
    AbstractOpenGLWidget(parent)
{
    vbo=nullptr;
    vboR=nullptr;
    camDist=10;
    thetaAngle=0;
    phiAngle=90;
    colorShaderProgram=nullptr;
    updateEyePos();
    anchorGeometry=nullptr;
    numPoints=0;
    pointSize=1;
    separateColors=false;
}

GLDisplayPointCloud::~GLDisplayPointCloud() {
    makeCurrent();
    if(colorShaderProgram != nullptr)
        delete colorShaderProgram;
    if(vbo != nullptr) {
        vbo->destroy();
        delete vbo;
    }

    if(vboR) {
        vboR->destroy();
        delete vboR;
        vboR=nullptr;
    }

    if(anchorGeometry != nullptr)
        delete anchorGeometry;
}

void GLDisplayPointCloud::initializeGL() {
    initializeOpenGLFunctions();
    glClearColor(0.5f,0.5f,1.0f,1.0f);

    colorShaderProgram=new QOpenGLShaderProgram();
    BuildShaders(":/glsl/ColorVis",colorShaderProgram);

    colorUniformModelView=colorShaderProgram->uniformLocation("ModelViewMat");
    colorUniformProjection=colorShaderProgram->uniformLocation("ProjectionMat");

    colorShaderVertexLocation=colorShaderProgram->attributeLocation("inPos");
    colorShaderColorLocation=colorShaderProgram->attributeLocation("inColor");


    updateEyePos();

    anchorGeometry=new AnchorGeometry();

    if(vbo) {
        vbo->destroy();
        delete vbo;
        vbo=nullptr;
    }

    if(vboR) {
        vboR->destroy();
        delete vboR;
        vboR=nullptr;
    }
}

void GLDisplayPointCloud::prepareObject(PointCloud *pc) {
    makeCurrent();

    if(vbo) {
        vbo->destroy();
        delete vbo;
        vbo=nullptr;
    }

    std::vector<float> vertices=pc->getVertices();
    vbo=new QOpenGLBuffer(QOpenGLBuffer::VertexBuffer);
    vbo->create();
    vbo->bind();
    vbo->setUsagePattern(QOpenGLBuffer::DynamicDraw);
    vbo->allocate(vertices.data(),vertices.size() * sizeof (float));
    vbo->release();

    numPoints=vertices.size() / 3;

    calcCamDist();

    updateEyePos();
}

void GLDisplayPointCloud::prepareObjectLR(PointCloud *pc, Vector3D n) {
    makeCurrent();

    if(vbo) {
        vbo->destroy();
        delete vbo;
        vbo=nullptr;
    }

    if(vboR) {
        vboR->destroy();
        delete vboR;
        vboR=nullptr;
    }

    std::vector<float> verticesL,verticesR;
    verticesL.clear();
    verticesR.clear();
    std::vector<Point3D> points=pc->getPoints();

    int i;
    double f=0;

    for(i=0;i<points.size();i++) {
        f=n.x * points[i].x + n.y * points[i].y + n.z * points[i].z;
        if(f < 0) {
            verticesL.push_back(points[i].x);
            verticesL.push_back(points[i].y);
            verticesL.push_back(points[i].z);
        }
        else {
            verticesR.push_back(points[i].x);
            verticesR.push_back(points[i].y);
            verticesR.push_back(points[i].z);
        }
    }

    vbo=new QOpenGLBuffer(QOpenGLBuffer::VertexBuffer);
    vbo->create();
    vbo->bind();
    vbo->setUsagePattern(QOpenGLBuffer::DynamicDraw);
    vbo->allocate(verticesL.data(),verticesL.size() * sizeof (float));
    vbo->release();

    vboR=new QOpenGLBuffer(QOpenGLBuffer::VertexBuffer);
    vboR->create();
    vboR->bind();
    vboR->setUsagePattern(QOpenGLBuffer::DynamicDraw);
    vboR->allocate(verticesR.data(),verticesR.size() * sizeof (float));
    vboR->release();

    numPoints=verticesL.size() / 3;
    numPointsR=verticesR.size() / 3;

    calcCamDist();

    updateEyePos();
}

void GLDisplayPointCloud::resizeGL(int w, int h) {
    m_proj.setToIdentity();
    m_proj.perspective(viewAngle,GLfloat(w) / GLfloat(h), 0.01f, 10000.0f);
}

void GLDisplayPointCloud::paintGL() {
    QMatrix4x4 modelViewMat;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    viewMatrix.setToIdentity();
    viewMatrix.lookAt(eyePos,centerEye,upEye);
    glPointSize(pointSize);
    worldMatrix.setToIdentity();
    modelViewMat=viewMatrix * worldMatrix;

    anchorGeometry->draw(m_proj,modelViewMat,0.05);

    if(vbo == nullptr)
        return;

    if(!separateColors) {
        colorShaderProgram->bind();
        colorShaderProgram->setUniformValue(colorUniformProjection,m_proj);
        colorShaderProgram->setUniformValue(colorUniformModelView,modelViewMat);

        vbo->bind();

        glVertexAttribPointer(colorShaderVertexLocation, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(colorShaderVertexLocation);

        colorShaderProgram->setAttributeValue(colorShaderColorLocation,0.0f,1.0f,0.0f);

        glDrawArrays(GL_POINTS, 0, numPoints);

        vbo->release();

        colorShaderProgram->release();
    }
    else {
        colorShaderProgram->bind();
        colorShaderProgram->setUniformValue(colorUniformProjection,m_proj);
        colorShaderProgram->setUniformValue(colorUniformModelView,modelViewMat);

        vbo->bind();

        glVertexAttribPointer(colorShaderVertexLocation, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(colorShaderVertexLocation);

        colorShaderProgram->setAttributeValue(colorShaderColorLocation,1.0f,0.0f,0.0f);

        glDrawArrays(GL_POINTS, 0, numPoints);

        vbo->release();

        vboR->bind();
        glVertexAttribPointer(colorShaderVertexLocation, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(colorShaderVertexLocation);

        colorShaderProgram->setAttributeValue(colorShaderColorLocation,0.0f,0.0f,1.0f);

        glDrawArrays(GL_POINTS, 0, numPointsR);

        vboR->release();

        colorShaderProgram->release();
    }
}

void GLDisplayPointCloud::setSeparateColors(bool newSeparateColors)
{
    separateColors = newSeparateColors;
}

void GLDisplayPointCloud::setPointSize(double newPointSize)
{
    pointSize = newPointSize;
}

