#ifndef GLDISPLAYPOINTCLOUD_H
#define GLDISPLAYPOINTCLOUD_H

#include "OpenGL/abstractopenglwidget.h"
#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <QOpenGLShaderProgram>
#include <QOpenGLBuffer>
#include <QOpenGLVertexArrayObject>
#include "anchorgeometry.h"
#include "Util/pointcloud.h"

class GLDisplayPointCloud : public AbstractOpenGLWidget
{
public:
    GLDisplayPointCloud(QWidget *parent=nullptr);
    ~GLDisplayPointCloud();

    void prepareObject(PointCloud *pc);
    void prepareObjectLR(PointCloud *pc, Vector3D n);

    void setPointSize(double newPointSize);

    void setSeparateColors(bool newSeparateColors);

protected:
    void initializeGL() override;
    void resizeGL(int w, int h) override;
    void paintGL() override;

    QOpenGLShaderProgram *colorShaderProgram;
    int colorShaderVertexLocation,colorShaderColorLocation;
    QOpenGLBuffer *vbo,*vboR;

    int colorUniformProjection, colorUniformModelView;

    int numPoints,numPointsR;

    double pointSize;

    AnchorGeometry *anchorGeometry;

    QMatrix4x4 m_proj,worldMatrix,viewMatrix;

    bool separateColors;
};

#endif // GLDISPLAYPOINTCLOUD_H
